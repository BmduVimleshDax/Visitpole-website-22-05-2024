<div class="footer text-center">
    <div class="container bg-secondary text-light p-3">
        <b class="copyright">&copy; 2024 VisitPole - visitpole.com </b>All rights reserved.
    </div>
</div>